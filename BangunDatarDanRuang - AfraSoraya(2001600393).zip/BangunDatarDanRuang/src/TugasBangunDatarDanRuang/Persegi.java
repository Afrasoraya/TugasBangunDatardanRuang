package TugasBangunDatarDanRuang;

public class Persegi extends BangunDatar{
	private int sisi;
	
	
	@Override
	double luas() {
		double luas = sisi *sisi;
		System.out.println("Luas persegi: "+luas);
		return super.luas();
	}

	@Override
	double keliling() {
		double keliling = 4*sisi;
		System.out.println("Keliling persegi: " + keliling);
		return super.keliling();
	}
		public int getSisi() {
			return sisi;
		}

		public void setSisi(int sisi) {
			this.sisi = sisi;
		}

		public Persegi(int sisi) {
			super();
			this.sisi = sisi;
		}



}
