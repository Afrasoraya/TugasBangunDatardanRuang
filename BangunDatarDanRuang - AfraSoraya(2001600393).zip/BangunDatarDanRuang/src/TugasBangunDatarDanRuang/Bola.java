package TugasBangunDatarDanRuang;

public class Bola extends BangunRuang {

	private int r;

	@Override
	double luas() {
		double luas = (float)(4 * Math.PI * r * r);
		System.out.println("Luas bola: "+ luas);
		return super.luas();
	}

	@Override
	double keliling() {
		double keliling = (float) (1.3 * Math.PI*r*r);
		System.out.println("Keliling bola: " + keliling);
		return super.keliling();
	}

	@Override
	double volume() {
		double volume = (float) (1.3 * Math.PI*r*r*r);
		System.out.println("Volume bola: "+ volume);
		return super.volume();
	}

	public int getR() {
		return r;
	}

	public void setR(int r) {
		this.r = r;
	}

	public Bola(int r) {
		super();
		this.r = r;
	}
	
}

