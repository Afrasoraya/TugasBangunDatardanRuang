package TugasBangunDatarDanRuang;

public class BangunDatar {
	double luas(){
		return 0;
	}
	double keliling(){
		return 0;
	}
	double volume() {
		// TODO Auto-generated method stub
		return 0;
	}
	

}
